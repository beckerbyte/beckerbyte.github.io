# Text Analyzer

Ein simples Python-Tool zur Textanalyse:
- Wortanzahl
- Zeichenanzahl
- Häufigste Wörter

## Nutzung

```bash
python analyzer.py example.txt
```
